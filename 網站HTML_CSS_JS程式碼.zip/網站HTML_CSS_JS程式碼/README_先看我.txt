# 娛樂城推薦首選｜HTML / CSS / JavaScript

這是從目前網站的靜態建置結果拆出的三個程式檔：

- `index.html`：網頁結構與預先輸出的首頁內容。
- `style.css`：網站樣式。
- `script.js`：互動功能及網站前端程式（由 React/Vite 編譯產生，屬於瀏覽器可執行的 JavaScript bundle）。

將三個檔案放在同一個資料夾，技術人員可據此上架。`script.js` 是編譯後的程式碼；若要長期維護，請一併參照上一份「網站技術交接包」中的 `source/client/src/` 原始碼。

## 上架前注意

1. `index.html` 仍有正式網址 canonical / sitemap 等 SEO 資訊，外部上架時請改成新的正式網址。
2. 頁面主視覺和平台 Logo 仍使用 `/manus-storage/...` 路徑；這些原圖沒有隨本包提供，離開 Manus 後需由業主提供原圖、或用 `logo-candidates/` 裡的候選 Logo 替換，並更新 `script.js`/CSS 對應圖片路徑。
3. 這三個檔案是網站程式，不含外部託管帳號或網域設定；上架後仍需技術人員設定主機、HTTPS、正式網域與 sitemap。
